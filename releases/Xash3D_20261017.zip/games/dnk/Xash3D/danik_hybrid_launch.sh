#!/bin/bash
#
# Xash3D (Half-Life) launcher. danik_hybrid_ports (Scripts/danik_hybrid_ports.sh)
# runs it when the Xash3D core is loaded (also with a game's set name, from
# its menu entry: MISTER_HYBRID_SET, which the game reads) and stops it, with
# SIGTERM to the process group, when another core is loaded.
#
# Laid out after the per-core handlers of MiSTer Frontier by MiSTer Organize
# (https://github.com/MiSTerOrganize/MiSTer_Frontier, GPL-3.0), with thanks
# for the inspiration. Licensed under the GPL-3.0.

CORE="Xash3D"
GAMEDIR="/media/fat/games/dnk/$CORE"
LOGDIR="/media/fat/logs/dnk/$CORE"
LOG="$LOGDIR/xash3d.log"

cd "$GAMEDIR" || exit 1
mkdir -p "$LOGDIR" config saves

# Only once
exec 9> /tmp/xash3d.lock
flock -n 9 || exit 0

# Development: keep the core loaded without starting the game
[ -f /tmp/xash3d_nolaunch ] && exit 0

# FPGA settle after the core was just loaded
sleep 1

mv -f "$LOG" "$LOGDIR/xash3d.prev.log" 2>/dev/null

# What the game prints is kept in memory while it runs and goes to the log on
# the SD card when it has left. The card is mounted "sync": a line printed
# straight to it is a write that waits for the card, about 9ms in which the
# game stands still. (A game that is still running when the MiSTer is
# switched off leaves no log of that run.)
RUNLOG=/tmp/xash3d.log
: > "$RUNLOG"
savelog() {
    cat "$RUNLOG" >> "$LOG" 2>/dev/null
    : > "$RUNLOG"
}

# For the hybrid core drivers in the binary: which core to attach to and its
# default button mapping ("jn" in core/Xash3D.sv)
export MISTER_HYBRID_CORE="$CORE"
export MISTER_HYBRID_JN="A,B,X,Y,L,R,Select,Start"
# Everything the game writes stays in its folder
export HOME="$GAMEDIR"
export XDG_CONFIG_HOME="$GAMEDIR/config"
export XDG_DATA_HOME="$GAMEDIR/config"

# Both CPUs: the game takes CPU0 (better DDR3 bandwidth, Main_MiSTer lives on
# CPU1) and runs audio and the frame copy on CPU1. Everything else on the
# MiSTer (scripts, daemons, interrupts) lands on CPU0 as well: without the
# higher priority the game waits for it a quarter of the time and misses fields.
# Exit code 42: the player quit a game picked from a list (MH_UI_Menu), start
# again to show the list. Exit code 43: the core was loaded again while the
# game ran (MH_CoreReloaded), start again once it has settled, unless it was
# another core after all.
GAME=
# The game must not outlive us: on SIGTERM it saves its settings and quits
trap '[ -n "$GAME" ] && kill "$GAME" 2>/dev/null && wait "$GAME"; savelog; exit 0' TERM INT
while :; do
    # The games are the folders next to the binary (valve, gearbox, bshift)
    # and each keeps its settings and saved games in its own; which one the
    # engine runs is the menu entry's (MISTER_HYBRID_SET) or picked from a
    # list (MiSTer_SelectGame()). The engine sizes its window itself: 640x480
    # for the menu, 320x200 or 320x240 for the game.
    XASH3D_BASEDIR="$GAMEDIR" nice -n -20 taskset 0x03 ./Xash3D -ref soft -windowed >> "$RUNLOG" 2>&1 &
    GAME=$!
    wait "$GAME"
    RC=$?
    savelog
    if [ $RC -eq 43 ]; then
        sleep 1
        grep -q "^$CORE" /tmp/CORENAME 2>/dev/null || break
    elif [ $RC -ne 42 ]; then
        break
    fi
done
GAME=

# Unless another core was loaded meanwhile: a game that left with an error
# (one that crashed: 128 + the signal) and put no message up says so on the
# core's picture (./mh_message, host version 13), and a message stays there
# until the player leaves the core. Else back to the MiSTer menu.
if grep -q "^$CORE" /tmp/CORENAME 2>/dev/null; then
    if [ $RC -ne 0 ] && ! ./mh_message --shown >> "$LOG" 2>&1; then
        ./mh_message --error "The game stopped unexpectedly (exit code $RC).\nIts log: ${LOG#/media/fat/}" >> "$LOG" 2>&1
        sleep 0.1
    fi
    ./mh_message --shown >> "$LOG" 2>&1 || echo "load_core /media/fat/menu.rbf" > /dev/MiSTer_cmd
fi
